const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';
const API_KEY = 'AIzaSyD5fpkAyZfzLfs6XRpDWE_5OUpWVWbtBjM'; // WARNING: Exposed in client-side code
let previousDialogue = '';

async function generateDialogue() {
  const situation = document.getElementById('situation').value.trim();
  if (!situation) {
    alert('Please enter a scene description!');
    return;
  }
  document.getElementById('loading').style.display = 'block';
  const messagesContainer = document.querySelector('.ai-chat-messages');
  try {
    // Construct prompt for concise movie-style dialogue with stage directions
    let prompt = `Generate a movie-style dialogue script for this situation:\n\n${situation}\n\n`;
    if (previousDialogue) {
      prompt += `Continue the dialogue script, maintaining the same characters and style:\n${previousDialogue}\n\n`;
    }
    prompt += `The dialogue must be formatted as a script with character names (e.g., Alex, Sophie) followed by a colon, and their spoken lines limited to 1-2 short sentences. Include brief stage directions in parentheses (e.g., (teary-eyed), (whispers)) where appropriate to enhance the scene, but keep them minimal. Ensure the dialogue is realistic, engaging, and matches the genre and tone of the situation. Avoid lengthy exchanges or excessive narrative descriptions. Example output for "Romantic Drama, Scene: Two lovers saying goodbye at a train station":
Alex: "Stay. Just for one more minute."
Sophie: (teary-eyed) "If I stay one more minute, I’ll never leave."
Alex: (whispers) "Then don’t."
(Train whistle blows, Sophie slowly steps back, eyes locked with his.)`;

    // Prepare request body
    const requestBody = {
      contents: [
        {
          parts: [
            { text: prompt }
          ]
        }
      ]
    };

    // Send request to Gemini API
    const response = await fetch(`${API_URL}?key=${API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    const generatedText = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
    if (!generatedText) {
      throw new Error('No valid response from Gemini API');
    }

    // Store the dialogue for continuation
    previousDialogue = generatedText;

    // Format the dialogue with character names and stage directions
    const formattedDialogue = generatedText.split('\n').map(line => {
      if (line.includes(':')) {
        const parts = line.split(':');
        const character = parts[0].trim();
        const characterClass = character === 'Character A' ? 'character-a' : character === 'Character B' ? 'character-b' : '';
        return `<div class="dialogue-line"><strong class="${characterClass}">${parts[0]}:</strong> <span>${parts.slice(1).join(':').trim()}</span></div>`;
      } else if (line.trim().startsWith('(') && line.trim().endsWith(')')) {
        return `<div class="dialogue-line stage-direction">${line}</div>`;
      }
      return `<div class="dialogue-line">${line}</div>`;
    }).join('');

    // Append the dialogue as a new message
    const newMessage = document.createElement('div');
    newMessage.classList.add('ai-message');
    newMessage.innerHTML = `
      <div class="ai-avatar">AI</div>
      <div class="ai-message-content">${formattedDialogue}</div>
    `;
    messagesContainer.appendChild(newMessage);

    // Scroll to the bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  } catch (error) {
    console.error('Error generating dialogue:', error);
    const errorMessage = document.createElement('div');
    errorMessage.classList.add('ai-message');
    errorMessage.innerHTML = `
      <div class="ai-avatar">AI</div>
      <div class="ai-message-content" style="color: #dc2626;">
        Error: Could not generate dialogue: ${error.message}. Please try again.
      </div>
    `;
    messagesContainer.appendChild(errorMessage);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  } finally {
    document.getElementById('loading').style.display = 'none';
    document.getElementById('situation').value = ''; // Clear input
  }
}

function continueDialogue() {
  if (!previousDialogue) {
    alert('No dialogue to continue! Generate some dialogue first.');
    return;
  }
  generateDialogue();
}

function newScene() {
  previousDialogue = '';
  const messagesContainer = document.querySelector('.ai-chat-messages');
  messagesContainer.innerHTML = `
    <div class="ai-message">
      <div class="ai-avatar">AI</div>
      <div class="ai-message-content">
        Hello! Enter a movie scene description (e.g., "Romantic Drama, Scene: Two lovers saying goodbye at a train station") and I'll generate a realistic movie-style dialogue for you.
      </div>
    </div>
  `;
  document.getElementById('situation').value = '';
}

// Allow Enter key to trigger dialogue generation
document.getElementById('situation').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    generateDialogue();
  }
});